Please run the setup at libraries/java/README.txt before continuing.

To build the Android sample you need to import into Android Studio, or run "sh gradlew build".

To import into Android Studio:
1. From the "Welcome to Android Studio" window select "Open an existing Android Studio project"
2. Navigation to and select $PACKAGE_ROOT/samples/android/
3. Once loaded hit the green "Play" button
