NOTE: THE SAMPLE APP SOUNDS ARE *NOT* INTENDED FOR COMMERCIAL USE.

For official audio cues, please visit the below url.

https://developer.amazon.com/public/solutions/alexa/alexa-voice-service/content/alexa-voice-service-ux-design-guidelines#sounds.
